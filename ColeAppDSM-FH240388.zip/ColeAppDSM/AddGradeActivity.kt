package com.example.desafio_moviles_fh240388.grades

import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.example.desafio_moviles_fh240388.R
import com.example.desafio_moviles_fh240388.models.Grade
import com.example.desafio_moviles_fh240388.models.Student
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore

class AddGradeActivity : AppCompatActivity() {
    private val db = FirebaseFirestore.getInstance()
    private val auth = FirebaseAuth.getInstance()
    private lateinit var spinnerStudent: Spinner
    private lateinit var spinnerGrade: Spinner
    private lateinit var spinnerSubject: Spinner
    private lateinit var etScore: EditText
    private lateinit var btnSave: Button

    private val studentList = mutableListOf<Student>()
    private val studentNames = mutableListOf<String>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_add_grade)

        spinnerStudent = findViewById(R.id.spinnerStudent)
        spinnerGrade = findViewById(R.id.spinnerGrade)
        spinnerSubject = findViewById(R.id.spinnerSubject)
        etScore = findViewById(R.id.etScore)
        btnSave = findViewById(R.id.btnSaveGrade)

        spinnerGrade.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, listOf("1°", "2°", "3°", "4°", "5°"))
        spinnerSubject.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, listOf("Matemáticas", "Ciencias", "Lenguaje", "Historia", "Inglés"))

        loadStudentsIntoSpinner()

        btnSave.setOnClickListener {
            val pos = spinnerStudent.selectedItemPosition
            if (pos < 0 || pos >= studentList.size) {
                Toast.makeText(this, "Selecciona un estudiante", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            val studentId = studentList[pos].id
            val gradeLevel = spinnerGrade.selectedItem.toString()
            val subject = spinnerSubject.selectedItem.toString()
            val score = etScore.text.toString().toDoubleOrNull()

            if (score == null || score < 0.0 || score > 10.0) {
                Toast.makeText(this, "Ingresa una nota entre 0 y 10", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val docRef = db.collection("grades").document()
            val grade = Grade(
                id = docRef.id,
                studentId = studentId,
                gradeLevel = gradeLevel,
                subject = subject,
                finalScore = score,
                createdBy = auth.currentUser?.uid ?: ""
            )
            docRef.set(grade)
                .addOnSuccessListener {
                    Toast.makeText(this, "Nota guardada", Toast.LENGTH_SHORT).show()
                    finish()
                }
                .addOnFailureListener { e -> Toast.makeText(this, "Error: ${e.message}", Toast.LENGTH_LONG).show() }
        }
    }

    private fun loadStudentsIntoSpinner() {
        db.collection("students")
            .whereEqualTo("createdBy", auth.currentUser?.uid)
            .get()
            .addOnSuccessListener { result ->
                studentList.clear()
                studentNames.clear()
                for (doc in result) {
                    val s = doc.toObject(Student::class.java)
                    studentList.add(s)
                    studentNames.add(s.fullName)
                }
                val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, studentNames)
                adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
                spinnerStudent.adapter = adapter
            }
            .addOnFailureListener { e -> Toast.makeText(this, "Error: ${e.message}", Toast.LENGTH_LONG).show() }
    }
}
