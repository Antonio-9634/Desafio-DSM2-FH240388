package com.example.desafio_moviles_fh240388.students

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.example.desafio_moviles_fh240388.R
import com.example.desafio_moviles_fh240388.models.Student
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore

class StudentListActivity : AppCompatActivity() {
    private val db = FirebaseFirestore.getInstance()
    private val auth = FirebaseAuth.getInstance()
    private val students = mutableListOf<Student>()
    private lateinit var listView: ListView
    private lateinit var adapter: ArrayAdapter<String>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_student_list)

        listView = findViewById(R.id.lvStudents)
        val btnAdd = findViewById<Button>(R.id.btnAddStudent)
        val btnAddGrade = findViewById<Button>(R.id.btnAddGrade)
        val btnLogout = findViewById<Button>(R.id.btnLogout)

        adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, ArrayList<String>())
        listView.adapter = adapter

        btnAdd.setOnClickListener {
            startActivity(Intent(this, AddStudentActivity::class.java))
        }
        btnAddGrade.setOnClickListener {
            startActivity(Intent(this, com.example.desafio_moviles_fh240388.grades.AddGradeActivity::class.java))
        }
        btnLogout.setOnClickListener {
            auth.signOut()
            finish()
        }

        listView.onItemClickListener = AdapterView.OnItemClickListener { _, _, position, _ ->
            val st = students[position]
            showStudentOptions(st)
        }
    }

    override fun onResume() {
        super.onResume()
        loadStudents()
    }

    private fun loadStudents() {
        db.collection("students")
            .whereEqualTo("createdBy", auth.currentUser?.uid)
            .get()
            .addOnSuccessListener { result ->
                students.clear()
                val names = ArrayList<String>()
                for (doc in result) {
                    val s = doc.toObject(Student::class.java)
                    students.add(s)
                    names.add("${s.fullName} — ${s.age} años")
                }
                adapter.clear()
                adapter.addAll(names)
                adapter.notifyDataSetChanged()
            }
            .addOnFailureListener { e ->
                Toast.makeText(this, "Error: ${e.message}", Toast.LENGTH_LONG).show()
            }
    }

    private fun showStudentOptions(student: Student) {
        val options = arrayOf("Editar", "Eliminar", "Ver Notas")
        AlertDialog.Builder(this).setTitle(student.fullName)
            .setItems(options) { _, which ->
                when (which) {
                    0 -> { // Editar
                        val i = Intent(this, EditStudentActivity::class.java)
                        i.putExtra("studentId", student.id)
                        startActivity(i)
                    }
                    1 -> { // Eliminar
                        deleteStudent(student)
                    }
                    2 -> { // Ver Notas
                        val i = Intent(this, com.example.desafio_moviles_fh240388.grades.EditGradeActivity::class.java)
                        i.putExtra("studentId", student.id)
                        startActivity(i)
                    }
                }
            }.show()
    }

    private fun deleteStudent(student: Student) {
        db.collection("students").document(student.id).delete()
            .addOnSuccessListener {
                Toast.makeText(this, "Estudiante eliminado", Toast.LENGTH_SHORT).show()
                loadStudents()
            }
            .addOnFailureListener { e -> Toast.makeText(this, "Error: ${e.message}", Toast.LENGTH_LONG).show() }
    }
}
