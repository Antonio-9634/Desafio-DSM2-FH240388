package com.example.desafio_moviles_fh240388.models

data class Grade(
    var id: String = "",
    var studentId: String = "",
    var gradeLevel: String = "",
    var subject: String = "",
    var finalScore: Double = 0.0,
    var createdBy: String = ""
)
