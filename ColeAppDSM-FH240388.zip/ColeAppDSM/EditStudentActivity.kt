package com.example.desafio_moviles_fh240388.students

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.desafio_moviles_fh240388.R
import com.example.desafio_moviles_fh240388.models.Student
import com.google.firebase.firestore.FirebaseFirestore

class EditStudentActivity : AppCompatActivity() {
    private val db = FirebaseFirestore.getInstance()
    private lateinit var etName: EditText
    private lateinit var etAge: EditText
    private lateinit var etAddress: EditText
    private lateinit var etPhone: EditText
    private lateinit var btnSave: Button
    private lateinit var btnDelete: Button
    private var studentId: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_edit_student)

        etName = findViewById(R.id.etFullName)
        etAge = findViewById(R.id.etAge)
        etAddress = findViewById(R.id.etAddress)
        etPhone = findViewById(R.id.etPhone)
        btnSave = findViewById(R.id.btnSaveStudent)
        btnDelete = findViewById(R.id.btnDeleteStudent)

        studentId = intent.getStringExtra("studentId")
        if (studentId == null) {
            Toast.makeText(this, "Estudiante no encontrado", Toast.LENGTH_LONG).show()
            finish()
            return
        }

        loadStudent()

        btnSave.setOnClickListener { saveChanges() }
        btnDelete.setOnClickListener { deleteStudent() }
    }

    private fun loadStudent() {
        studentId?.let { id ->
            db.collection("students").document(id).get()
                .addOnSuccessListener { doc ->
                    val s = doc.toObject(Student::class.java)
                    if (s != null) {
                        etName.setText(s.fullName)
                        etAge.setText(s.age.toString())
                        etAddress.setText(s.address)
                        etPhone.setText(s.phone)
                    }
                }
                .addOnFailureListener { e -> Toast.makeText(this, "Error: ${e.message}", Toast.LENGTH_LONG).show() }
        }
    }

    private fun saveChanges() {
        val name = etName.text.toString().trim()
        val ageStr = etAge.text.toString().trim()
        val address = etAddress.text.toString().trim()
        val phone = etPhone.text.toString().trim()

        if (name.isEmpty() || ageStr.isEmpty() || address.isEmpty() || phone.isEmpty()) {
            Toast.makeText(this, "Todos los campos son obligatorios", Toast.LENGTH_SHORT).show()
            return
        }
        val age = ageStr.toIntOrNull()
        if (age == null || age <= 0) {
            Toast.makeText(this, "Ingresa una edad válida", Toast.LENGTH_SHORT).show()
            return
        }

        val updated = mapOf(
            "fullName" to name,
            "age" to age,
            "address" to address,
            "phone" to phone
        )
        studentId?.let { id ->
            db.collection("students").document(id).update(updated)
                .addOnSuccessListener {
                    Toast.makeText(this, "Estudiante actualizado", Toast.LENGTH_SHORT).show()
                    finish()
                }
                .addOnFailureListener { e -> Toast.makeText(this, "Error: ${e.message}", Toast.LENGTH_LONG).show() }
        }
    }

    private fun deleteStudent() {
        studentId?.let { id ->
            db.collection("students").document(id).delete()
                .addOnSuccessListener {
                    Toast.makeText(this, "Estudiante eliminado", Toast.LENGTH_SHORT).show()
                    finish()
                }
                .addOnFailureListener { e -> Toast.makeText(this, "Error: ${e.message}", Toast.LENGTH_LONG).show() }
        }
    }
}
