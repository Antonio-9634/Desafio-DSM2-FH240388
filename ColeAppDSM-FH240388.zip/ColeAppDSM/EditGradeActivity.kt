package com.example.desafio_moviles_fh240388.grades

import android.os.Bundle
import android.view.View
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.example.desafio_moviles_fh240388.R
import com.example.desafio_moviles_fh240388.models.Grade
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore

class EditGradeActivity : AppCompatActivity() {
    private val db = FirebaseFirestore.getInstance()
    private val auth = FirebaseAuth.getInstance()
    private lateinit var lvGrades: ListView
    private val grades = mutableListOf<Grade>()
    private lateinit var adapter: ArrayAdapter<String>
    private val display = mutableListOf<String>()
    private var passedStudentId: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_edit_grade)

        lvGrades = findViewById(R.id.lvGrades)
        adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, display)
        lvGrades.adapter = adapter

        passedStudentId = intent.getStringExtra("studentId")

        lvGrades.onItemClickListener = AdapterView.OnItemClickListener { _, _, position, _ ->
            val g = grades[position]
            showGradeOptions(g)
        }
    }

    override fun onResume() {
        super.onResume()
        loadGrades()
    }

    private fun loadGrades() {
        val q = if (passedStudentId != null) {
            db.collection("grades").whereEqualTo("studentId", passedStudentId)
        } else {
            db.collection("grades").whereEqualTo("createdBy", auth.currentUser?.uid)
        }

        q.get()
            .addOnSuccessListener { result ->
                grades.clear()
                display.clear()
                for (doc in result) {
                    val g = doc.toObject(Grade::class.java)
                    grades.add(g)
                    display.add("${g.subject} — ${g.finalScore} (${g.gradeLevel})")
                }
                adapter.notifyDataSetChanged()
            }
            .addOnFailureListener { e -> Toast.makeText(this, "Error: ${e.message}", Toast.LENGTH_LONG).show() }
    }

    private fun showGradeOptions(grade: Grade) {
        val options = arrayOf("Editar", "Eliminar")
        AlertDialog.Builder(this).setTitle("${grade.subject} - ${grade.finalScore}")
            .setItems(options) { _, which ->
                when (which) {
                    0 -> editGrade(grade)
                    1 -> deleteGrade(grade)
                }
            }.show()
    }

    private fun editGrade(grade: Grade) {
        // Simplified: open AddGradeActivity prefilled isn't implemented here.
        // For brevity we will prompt a dialog to edit score only:
        val editText = EditText(this)
        editText.inputType = android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL
        editText.setText(grade.finalScore.toString())
        AlertDialog.Builder(this)
            .setTitle("Editar nota")
            .setView(editText)
            .setPositiveButton("Guardar") { _, _ ->
                val valStr = editText.text.toString().toDoubleOrNull()
                if (valStr == null || valStr < 0.0 || valStr > 10.0) {
                    Toast.makeText(this, "Nota inválida", Toast.LENGTH_SHORT).show()
                    return@setPositiveButton
                }
                db.collection("grades").document(grade.id).update(mapOf("finalScore" to valStr))
                    .addOnSuccessListener { Toast.makeText(this, "Nota actualizada", Toast.LENGTH_SHORT).show(); loadGrades() }
                    .addOnFailureListener { e -> Toast.makeText(this, "Error: ${e.message}", Toast.LENGTH_LONG).show() }
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    private fun deleteGrade(grade: Grade) {
        db.collection("grades").document(grade.id).delete()
            .addOnSuccessListener { Toast.makeText(this, "Nota eliminada", Toast.LENGTH_SHORT).show(); loadGrades() }
            .addOnFailureListener { e -> Toast.makeText(this, "Error: ${e.message}", Toast.LENGTH_LONG).show() }
    }
}
