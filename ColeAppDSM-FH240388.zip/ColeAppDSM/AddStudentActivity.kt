package com.example.desafio_moviles_fh240388.students

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.desafio_moviles_fh240388.R
import com.example.desafio_moviles_fh240388.models.Student
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore

class AddStudentActivity : AppCompatActivity() {
    private val db = FirebaseFirestore.getInstance()
    private val auth = FirebaseAuth.getInstance()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_add_student)

        val etName = findViewById<EditText>(R.id.etFullName)
        val etAge = findViewById<EditText>(R.id.etAge)
        val etAddress = findViewById<EditText>(R.id.etAddress)
        val etPhone = findViewById<EditText>(R.id.etPhone)
        val btnSave = findViewById<Button>(R.id.btnSaveStudent)

        btnSave.setOnClickListener {
            val name = etName.text.toString().trim()
            val ageStr = etAge.text.toString().trim()
            val address = etAddress.text.toString().trim()
            val phone = etPhone.text.toString().trim()

            if (name.isEmpty() || ageStr.isEmpty() || address.isEmpty() || phone.isEmpty()) {
                Toast.makeText(this, "Todos los campos son obligatorios", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            val age = ageStr.toIntOrNull()
            if (age == null || age <= 0) {
                Toast.makeText(this, "Ingresa una edad válida", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val studentRef = db.collection("students").document()
            val student = Student(
                id = studentRef.id,
                fullName = name,
                age = age,
                address = address,
                phone = phone,
                createdBy = auth.currentUser?.uid ?: ""
            )
            studentRef.set(student)
                .addOnSuccessListener {
                    Toast.makeText(this, "Estudiante guardado", Toast.LENGTH_SHORT).show()
                    finish()
                }
                .addOnFailureListener { e -> Toast.makeText(this, "Error: ${e.message}", Toast.LENGTH_LONG).show() }
        }
    }
}
