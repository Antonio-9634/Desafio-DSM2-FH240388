package com.example.desafio_moviles_fh240388.models

data class Student(
    var id: String = "",
    var fullName: String = "",
    var age: Int = 0,
    var address: String = "",
    var phone: String = "",
    var createdBy: String = ""
)
